# Ogzen Spin Demo
A standalone frontend demonstration of a multilingual Spin-to-Win site.

Important: this build uses virtual credits only. It does not accept real-money deposits,
connect to a payment provider, process withdrawals, or provide real-money gambling.

Open index.html in a browser.
